package com.iqtmusic.mobile.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val DarkColorScheme = darkColorScheme(
    primary = DarkPrimary,
    onPrimary = DarkOnPrimary,
    primaryContainer = DarkPrimaryContainer,
    onPrimaryContainer = DarkOnPrimaryContainer,
    secondary = DarkSecondary,
    onSecondary = DarkOnSecondary,
    secondaryContainer = DarkSecondaryContainer,
    onSecondaryContainer = DarkOnSecondaryContainer,
    tertiary = DarkTertiary,
    onTertiary = DarkOnTertiary,
    tertiaryContainer = DarkTertiaryContainer,
    onTertiaryContainer = DarkOnTertiaryContainer,
    error = DarkError,
    errorContainer = DarkErrorContainer,
    onError = DarkOnError,
    onErrorContainer = DarkOnErrorContainer,
    background = DarkBackground,
    onBackground = DarkOnBackground,
    surface = DarkSurface,
    onSurface = DarkOnSurface,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkOnSurfaceVariant,
    outline = DarkOutline,
    inverseOnSurface = DarkInverseOnSurface,
    inverseSurface = DarkInverseSurface,
    inversePrimary = DarkInversePrimary,
)

private val LightColorScheme = lightColorScheme(
    primary = LightPrimary,
    onPrimary = LightOnPrimary,
    primaryContainer = LightPrimaryContainer,
    onPrimaryContainer = LightOnPrimaryContainer,
    secondary = LightSecondary,
    onSecondary = LightOnSecondary,
    secondaryContainer = LightSecondaryContainer,
    onSecondaryContainer = LightOnSecondaryContainer,
    tertiary = LightTertiary,
    onTertiary = LightOnTertiary,
    tertiaryContainer = LightTertiaryContainer,
    onTertiaryContainer = LightOnTertiaryContainer,
    error = LightError,
    errorContainer = LightErrorContainer,
    onError = LightOnError,
    onErrorContainer = LightOnErrorContainer,
    background = LightBackground,
    onBackground = LightOnBackground,
    surface = LightSurface,
    onSurface = LightOnSurface,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = LightOnSurfaceVariant,
    outline = LightOutline,
    inverseOnSurface = LightInverseOnSurface,
    inverseSurface = LightInverseSurface,
    inversePrimary = LightInversePrimary,
)

private val IqtShapes = Shapes(
    extraSmall = androidx.compose.foundation.shape.RoundedCornerShape(10.dp),
    small = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
    medium = androidx.compose.foundation.shape.RoundedCornerShape(20.dp),
    large = androidx.compose.foundation.shape.RoundedCornerShape(26.dp),
    extraLarge = androidx.compose.foundation.shape.RoundedCornerShape(30.dp),
)

@Immutable
data class IqtPalette(
    val background: Color,
    val backgroundAlt: Color,
    val card: Color,
    val cardHover: Color,
    val elevated: Color,
    val border: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textMuted: Color,
)

private val LocalIqtPalette = staticCompositionLocalOf {
    IqtPalette(
        background = IqtNightBlack,
        backgroundAlt = IqtNightDark,
        card = IqtCard,
        cardHover = IqtCardHover,
        elevated = IqtElevated,
        border = IqtBorder,
        textPrimary = IqtTextPrimary,
        textSecondary = IqtTextSecondary,
        textMuted = IqtTextMuted,
    )
}

val MaterialTheme.iqtPalette: IqtPalette
    @Composable
    get() = LocalIqtPalette.current

@Composable
fun IqtMusicAndroidTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val palette = if (darkTheme) {
        IqtPalette(
            background = IqtNightBlack,
            backgroundAlt = IqtNightDark,
            card = IqtCard,
            cardHover = IqtCardHover,
            elevated = IqtElevated,
            border = IqtBorder,
            textPrimary = IqtTextPrimary,
            textSecondary = IqtTextSecondary,
            textMuted = IqtTextMuted,
        )
    } else {
        IqtPalette(
            background = LightBackground,
            backgroundAlt = LightSurface,
            card = LightSurfaceVariant,
            cardHover = LightSurfaceVariant.copy(alpha = 0.8f),
            elevated = LightSurface,
            border = LightOutline,
            textPrimary = LightOnBackground,
            textSecondary = LightOnSurfaceVariant,
            textMuted = LightOutline,
        )
    }

    CompositionLocalProvider(LocalIqtPalette provides palette) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = IqtTypography,
            shapes = IqtShapes,
            content = content,
        )
    }
}
