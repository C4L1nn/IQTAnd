package com.iqtmusic.mobile.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.iqtmusic.mobile.ui.theme.iqtPalette

@Composable
fun LyricsView(
    lyrics: String?,
    isLoading: Boolean,
    currentTrackTitle: String,
    currentTrackArtist: String,
    currentPosition: Long = 0L,
    trackDuration: Long = 0L,
    onRefresh: () -> Unit = {},
    onClose: () -> Unit = {},
    modifier: Modifier = Modifier,
) {
    val listState = rememberLazyListState()
    
    // Auto-scroll to current position if synced lyrics available
    LaunchedEffect(currentPosition) {
        if (currentPosition > 0 && trackDuration > 0) {
            val progress = currentPosition.toFloat() / trackDuration.toFloat()
            val targetIndex = (progress * 50).toInt() // Approximate line count
            if (targetIndex < listState.layoutInfo.visibleItemsInfo.size) {
                listState.animateScrollToItem(targetIndex)
            }
        }
    }
    
    Surface(
        modifier = modifier.fillMaxSize(),
        color = MaterialTheme.iqtPalette.background,
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = currentTrackTitle,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.iqtPalette.textPrimary
                        ),
                        maxLines = 1
                    )
                    Text(
                        text = currentTrackArtist,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = MaterialTheme.iqtPalette.textSecondary
                        ),
                        maxLines = 1
                    )
                }
                
                Row {
                    IconButton(
                        onClick = onRefresh,
                        modifier = Modifier.size(40.dp)
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                strokeWidth = 2.dp,
                                color = MaterialTheme.iqtPalette.textPrimary
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Rounded.Refresh,
                                contentDescription = "Yenile",
                                tint = MaterialTheme.iqtPalette.textPrimary
                            )
                        }
                    }
                    
                    IconButton(
                        onClick = onClose,
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Close,
                            contentDescription = "Kapat",
                            tint = MaterialTheme.iqtPalette.textPrimary
                        )
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Lyrics content
            when {
                isLoading -> {
                    LoadingLyricsView()
                }
                lyrics.isNullOrBlank() -> {
                    EmptyLyricsView()
                }
                else -> {
                    LyricsContentView(
                        lyrics = lyrics,
                        listState = listState,
                        currentPosition = currentPosition,
                        trackDuration = trackDuration
                    )
                }
            }
        }
    }
}

@Composable
private fun LoadingLyricsView() {
    val infiniteTransition = rememberInfiniteTransition()
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            CircularProgressIndicator(
                modifier = Modifier.size(48.dp),
                strokeWidth = 3.dp,
                color = MaterialTheme.iqtPalette.textPrimary
            )
            
            Text(
                text = "Þarký sözleri yükleniyor...",
                style = MaterialTheme.typography.bodyLarge.copy(
                    color = MaterialTheme.iqtPalette.textSecondary,
                    alpha = alpha
                )
            )
        }
    }
}

@Composable
private fun EmptyLyricsView() {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .background(
                        color = MaterialTheme.iqtPalette.card.copy(alpha = 0.5f),
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.MusicNote,
                    contentDescription = null,
                    tint = MaterialTheme.iqtPalette.textMuted,
                    modifier = Modifier.size(40.dp)
                )
            }
            
            Text(
                text = "Þarký sözleri bulunamadý",
                style = MaterialTheme.typography.titleMedium.copy(
                    color = MaterialTheme.iqtPalette.textSecondary,
                    fontWeight = FontWeight.Medium
                )
            )
            
            Text(
                text = "Bu þarký için sözler mevcut deðil",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = MaterialTheme.iqtPalette.textMuted
                ),
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun LyricsContentView(
    lyrics: String,
    listState: androidx.compose.foundation.lazy.LazyListState,
    currentPosition: Long,
    trackDuration: Long
) {
    val lines = lyrics.split("\n").filter { it.isNotBlank() }
    
    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        itemsIndexed(lines) { index, line ->
            val isActive = if (trackDuration > 0) {
                val progress = currentPosition.toFloat() / trackDuration.toFloat()
                val lineProgress = index.toFloat() / lines.size.toFloat()
                lineProgress <= progress && progress < lineProgress + (1f / lines.size.toFloat())
            } else false
            
            LyricsLine(
                text = line,
                isActive = isActive,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }
    }
}

@Composable
private fun LyricsLine(
    text: String,
    isActive: Boolean,
    modifier: Modifier = Modifier
) {
    val textColor = if (isActive) {
        MaterialTheme.colorScheme.primary
    } else {
        MaterialTheme.iqtPalette.textSecondary
    }
    
    val fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal
    val fontSize = if (isActive) 18.sp else 16.sp
    
    Text(
        text = text,
        style = MaterialTheme.typography.bodyLarge.copy(
            color = textColor,
            fontWeight = fontWeight,
            fontSize = fontSize
        ),
        textAlign = TextAlign.Center,
        modifier = modifier,
        maxLines = 2
    )
}

@Composable
fun LyricsPreviewButton(
    onLyricsClick: () -> Unit,
    hasLyrics: Boolean,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onLyricsClick,
        modifier = modifier,
        shape = RoundedCornerShape(8.dp),
        color = MaterialTheme.iqtPalette.card.copy(alpha = 0.8f)
    ) {
        Row(
            modifier = Modifier
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = Icons.Rounded.MusicNote,
                contentDescription = "Sözler",
                tint = if (hasLyrics) MaterialTheme.colorScheme.primary else MaterialTheme.iqtPalette.textMuted,
                modifier = Modifier.size(16.dp)
            )
            
            Text(
                text = if (hasLyrics) "Sözleri göster" else "Sözler yok",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = if (hasLyrics) MaterialTheme.colorScheme.primary else MaterialTheme.iqtPalette.textMuted
                )
            )
        }
    }
}
