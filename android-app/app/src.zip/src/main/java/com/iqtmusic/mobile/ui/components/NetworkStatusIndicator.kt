package com.iqtmusic.mobile.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.SignalWifiConnected
import androidx.compose.material.icons.rounded.SignalWifiOff
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.iqtmusic.mobile.data.network.NetworkMonitor

@Composable
fun NetworkStatusIndicator(
    isConnected: Boolean,
    networkType: NetworkMonitor.NetworkType,
    connectionSpeed: NetworkMonitor.ConnectionSpeed,
    modifier: Modifier = Modifier,
) {
    AnimatedVisibility(
        visible = !isConnected,
        enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
        exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
        modifier = modifier
    ) {
        OfflineBanner()
    }
}

@Composable
private fun OfflineBanner() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.errorContainer)
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(
                imageVector = Icons.Rounded.SignalWifiOff,
                contentDescription = "Offline",
                tint = MaterialTheme.colorScheme.onErrorContainer,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Çevrimdçi mod - Baðlantý yok",
                style = MaterialTheme.typography.bodySmall.copy(
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onErrorContainer
                )
            )
        }
    }
}

@Composable
fun NetworkStatusChip(
    isConnected: Boolean,
    networkType: NetworkMonitor.NetworkType,
    connectionSpeed: NetworkMonitor.ConnectionSpeed,
    modifier: Modifier = Modifier,
) {
    if (!isConnected) {
        NetworkChip(
            icon = Icons.Rounded.SignalWifiOff,
            text = "Çevrimdýþý",
            color = MaterialTheme.colorScheme.error,
            modifier = modifier
        )
    } else {
        val (icon, text, color) = when (networkType) {
            NetworkMonitor.NetworkType.WIFI -> Triple(
                Icons.Rounded.SignalWifiConnected,
                "WiFi",
                MaterialTheme.colorScheme.primary
            )
            NetworkMonitor.NetworkType.CELLULAR -> Triple(
                Icons.Rounded.SignalWifiConnected,
                "Mobil",
                MaterialTheme.colorScheme.secondary
            )
            NetworkMonitor.NetworkType.ETHERNET -> Triple(
                Icons.Rounded.SignalWifiConnected,
                "Ethernet",
                MaterialTheme.colorScheme.tertiary
            )
            else -> Triple(
                Icons.Rounded.Warning,
                "Bilinmeyen",
                MaterialTheme.colorScheme.outline
            )
        }
        
        NetworkChip(
            icon = icon,
            text = text,
            color = color,
            modifier = modifier
        )
    }
}

@Composable
private fun NetworkChip(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    text: String,
    color: Color,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier
            .background(
                color = color.copy(alpha = 0.1f),
                shape = MaterialTheme.shapes.small
            )
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = text,
            tint = color,
            modifier = Modifier.size(14.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall.copy(
                color = color,
                fontWeight = FontWeight.Medium
            )
        )
    }
}
